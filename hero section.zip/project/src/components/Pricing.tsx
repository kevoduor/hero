import React from 'react';
import { Check } from 'lucide-react';

const plans = [
  {
    name: 'Basic',
    price: 180,
    annualPrice: 1800,
    features: [
      'Core management features',
      'Basic support',
      'Limited integrations with third-party tools'
    ]
  },
  {
    name: 'Professional',
    price: 270,
    annualPrice: 2700,
    popular: true,
    features: [
      'All features in the Basic Plan',
      'Advanced analytics and reporting',
      'Priority support',
      'Enhanced integrations'
    ]
  },
  {
    name: 'Premium',
    price: 360,
    annualPrice: 3600,
    features: [
      'All features in the Professional Plan',
      'Customizable features',
      'Dedicated account manager',
      '24/7 support',
      'Additional training and onboarding'
    ]
  }
];

export default function Pricing() {
  const [annual, setAnnual] = React.useState(true);

  return (
    <div className="py-24 bg-gray-50" id="pricing">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900">
            Flexible Pricing for Clinics of All Sizes
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            Choose between monthly or annual plans. Annual plans include two months free!
          </p>
          
          <div className="mt-8 inline-flex items-center gap-4 bg-gray-100 p-1 rounded-lg">
            <button
              onClick={() => setAnnual(false)}
              className={\`px-4 py-2 rounded-md \${!annual ? 'bg-white shadow-sm' : ''}\`}
            >
              Monthly
            </button>
            <button
              onClick={() => setAnnual(true)}
              className={\`px-4 py-2 rounded-md \${annual ? 'bg-white shadow-sm' : ''}\`}
            >
              Annual
            </button>
          </div>
        </div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan) => (
            <div 
              key={plan.name}
              className={\`relative bg-white rounded-2xl shadow-sm p-8 \${
                plan.popular ? 'ring-2 ring-blue-600' : ''
              }\`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <span className="bg-blue-600 text-white px-4 py-1 rounded-full text-sm">
                    Most Popular
                  </span>
                </div>
              )}
              
              <h3 className="text-xl font-semibold text-gray-900">{plan.name}</h3>
              
              <div className="mt-4 flex items-baseline">
                <span className="text-4xl font-bold text-gray-900">
                  ${annual ? plan.annualPrice / 12 : plan.price}
                </span>
                <span className="ml-2 text-gray-600">/month</span>
              </div>
              
              {annual && (
                <p className="mt-2 text-sm text-gray-500">
                  ${plan.annualPrice} billed annually
                </p>
              )}

              <ul className="mt-8 space-y-4">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-blue-600 mt-0.5" />
                    <span className="text-gray-600">{feature}</span>
                  </li>
                ))}
              </ul>

              <button className="mt-8 w-full bg-gray-50 text-gray-900 py-3 rounded-lg hover:bg-gray-100 transition-colors">
                Get Started
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}