import React, { useEffect, useRef } from 'react';
import { PARTICLE_CONFIG } from '../constants/theme';
import { createParticles } from '../utils/canvas';
import type { AudioParticle } from '../types';

export default function AudioSphere({ className = "w-12 h-12" }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<AudioParticle[]>([]);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Enable global composite operations for glow effect
    ctx.globalCompositeOperation = 'lighter';
    
    let animationFrameId: number;
    particlesRef.current = createParticles(PARTICLE_CONFIG.count);
    let frame = 0;

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      frame++;

      particlesRef.current.forEach((particle, index) => {
        // Add subtle wave motion
        const wave = Math.sin(frame * 0.02 + index * 0.5) * 2;
        particle.angle += particle.velocity;
        
        const x = canvas.width / 2 + Math.cos(particle.angle) * (particle.amplitude + wave);
        const y = canvas.height / 2 + Math.sin(particle.angle) * (particle.amplitude + wave);

        // Create glow effect
        const gradient = ctx.createRadialGradient(x, y, 0, x, y, particle.radius * 2);
        gradient.addColorStop(0, particle.color);
        gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');

        // Draw glowing particle
        ctx.beginPath();
        ctx.arc(x, y, particle.radius * 2, 0, Math.PI * 2);
        ctx.fillStyle = gradient;
        ctx.fill();

        // Draw core particle
        ctx.beginPath();
        ctx.arc(x, y, particle.radius, 0, Math.PI * 2);
        ctx.fillStyle = particle.color;
        ctx.fill();
      });

      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      width={48}
      height={48}
      className={className}
    />
  );
}