import React from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import AudioSphere from './AudioSphere';

const benefits = [
  'Improve Patient Retention',
  'Reduce No-Shows by 30%',
  'Automate Administrative Tasks',
  'Better Reporting and Analytics',
  'Grow Your Practice and Attract More Patients'
];

export default function Hero() {
  return (
    <div className="relative pt-32 pb-16 sm:pt-40 sm:pb-24 overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-cyan-50 opacity-70" />
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center relative">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-24">
            <AudioSphere className="w-48 h-48 opacity-50" />
          </div>
          
          <h1 className="text-4xl sm:text-6xl font-bold text-gray-900 tracking-tight">
            AI-Powered Management System
            <br />
            <span className="text-blue-600">for Dental Clinics</span>
          </h1>
          
          <p className="mt-6 text-xl text-gray-600 max-w-3xl mx-auto">
            Streamline your dental practice with voice-powered patient management, 
            intelligent scheduling, and real-time analytics.
          </p>

          <div className="mt-10 flex justify-center gap-4">
            <a 
              href="https://calendly.com/niahai"
              target="_blank"
              rel="noopener noreferrer" 
              className="group bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors text-lg inline-flex items-center gap-2"
            >
              Book Demo
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </a>
            <button className="border border-gray-300 text-gray-700 px-8 py-3 rounded-lg hover:bg-gray-50 transition-colors text-lg">
              Watch Video
            </button>
          </div>

          <div className="mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-w-5xl mx-auto text-left">
            {benefits.map((benefit, index) => (
              <div key={index} className="flex items-start gap-3 bg-white/60 backdrop-blur-sm p-4 rounded-lg">
                <CheckCircle2 className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700">{benefit}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}