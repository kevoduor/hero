import { SPHERE_CONFIG } from './constants';
import type { SpherePoint } from './types';

export function create3DSphere(radius: number, density: number): SpherePoint[] {
  const points: SpherePoint[] = [];
  const phi = Math.PI * (3 - Math.sqrt(5)); // Golden angle

  for (let i = 0; i < density; i++) {
    const y = 1 - (i / (density - 1)) * 2;
    const r = Math.sqrt(1 - y * y);
    const theta = phi * i;

    const x = Math.cos(theta) * r;
    const z = Math.sin(theta) * r;

    points.push({
      x: x * radius,
      y: y * radius,
      z: z * radius,
      radius: SPHERE_CONFIG.minPointRadius + 
        Math.random() * (SPHERE_CONFIG.maxPointRadius - SPHERE_CONFIG.minPointRadius),
      color: SPHERE_CONFIG.colors[Math.floor(Math.random() * SPHERE_CONFIG.colors.length)]
    });
  }

  return points;
}