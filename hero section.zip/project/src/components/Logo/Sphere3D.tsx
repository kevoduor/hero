import React, { useEffect, useRef } from 'react';
import { SPHERE_CONFIG } from './constants';
import { create3DSphere } from './utils';
import type { SpherePoint } from './types';

export default function Sphere3D({ className = "w-12 h-12" }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pointsRef = useRef<SpherePoint[]>([]);
  const angleRef = useRef(0);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    pointsRef.current = create3DSphere(SPHERE_CONFIG.radius, SPHERE_CONFIG.density);
    
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Sort points by z-index for proper 3D rendering
      const sortedPoints = [...pointsRef.current].sort((a, b) => b.z - a.z);
      
      // Rotate points
      angleRef.current += SPHERE_CONFIG.rotationSpeed;
      const cosA = Math.cos(angleRef.current);
      const sinA = Math.sin(angleRef.current);

      sortedPoints.forEach(point => {
        // Rotate around Y axis
        const x = point.x * cosA - point.z * sinA;
        const z = point.z * cosA + point.x * sinA;
        
        // Calculate projection
        const scale = SPHERE_CONFIG.perspective / (SPHERE_CONFIG.perspective - z);
        const px = x * scale + canvas.width / 2;
        const py = point.y * scale + canvas.height / 2;

        // Create gradient for depth effect
        const gradient = ctx.createRadialGradient(px, py, 0, px, py, point.radius * scale);
        const alpha = (z + SPHERE_CONFIG.radius) / (SPHERE_CONFIG.radius * 2);
        gradient.addColorStop(0, point.color.replace(')', `, ${alpha})`));
        gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');

        // Draw point with glow
        ctx.beginPath();
        ctx.arc(px, py, point.radius * scale * 2, 0, Math.PI * 2);
        ctx.fillStyle = gradient;
        ctx.fill();

        // Draw core
        ctx.beginPath();
        ctx.arc(px, py, point.radius * scale, 0, Math.PI * 2);
        ctx.fillStyle = point.color.replace(')', `, ${alpha})`);
        ctx.fill();
      });

      requestAnimationFrame(animate);
    };

    animate();
  }, []);

  return (
    <canvas
      ref={canvasRef}
      width={48}
      height={48}
      className={className}
    />
  );
}