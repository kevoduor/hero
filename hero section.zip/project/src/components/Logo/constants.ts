export const SPHERE_CONFIG = {
  radius: 15,
  density: 40,
  perspective: 100,
  rotationSpeed: 0.005,
  colors: [
    'rgba(59, 130, 246',  // blue
    'rgba(139, 92, 246',  // purple
    'rgba(236, 72, 153',  // pink
    'rgba(6, 182, 212',   // cyan
  ],
  minPointRadius: 0.8,
  maxPointRadius: 1.2,
} as const;