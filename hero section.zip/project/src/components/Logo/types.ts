export interface SpherePoint {
  x: number;
  y: number;
  z: number;
  radius: number;
  color: string;
}