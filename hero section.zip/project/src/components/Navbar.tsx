import React from 'react';
import Sphere3D from './Logo/Sphere3D';

export default function Navbar() {
  return (
    <nav className="fixed w-full bg-white/80 backdrop-blur-md z-50 border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-2">
            <Sphere3D className="w-8 h-8" />
            <span className="text-xl font-light tracking-tight text-gray-900">niah</span>
          </div>
          <div className="hidden md:flex items-center space-x-8">
            <a href="#features" className="text-gray-600 hover:text-gray-900">Features</a>
            <a href="#solutions" className="text-gray-600 hover:text-gray-900">Solutions</a>
            <a href="#pricing" className="text-gray-600 hover:text-gray-900">Pricing</a>
            <a 
              href="https://calendly.com/niahai" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Book Demo
            </a>
          </div>
        </div>
      </div>
    </nav>
  );
}