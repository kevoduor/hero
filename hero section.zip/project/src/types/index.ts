import { LucideIcon } from 'lucide-react';

export interface Feature {
  icon: LucideIcon;
  title: string;
  description: string;
}

export interface AudioParticle {
  x: number;
  y: number;
  radius: number;
  color: string;
  velocity: number;
  amplitude: number;
  angle: number;
}