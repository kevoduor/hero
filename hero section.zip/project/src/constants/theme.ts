export const COLORS = {
  primary: '#3B82F6',
  secondary: '#8B5CF6',
  accent: '#EC4899',
  highlight: '#06B6D4',
} as const;

export const PARTICLE_CONFIG = {
  count: 24,
  colors: [
    'rgba(59, 130, 246, 0.8)',  // blue
    'rgba(139, 92, 246, 0.8)',  // purple
    'rgba(236, 72, 153, 0.8)',  // pink
    'rgba(6, 182, 212, 0.8)',   // cyan
  ],
  minRadius: 3,
  maxRadius: 6,
  minVelocity: 0.01,
  maxVelocity: 0.02,
  minAmplitude: 18,
  maxAmplitude: 22,
  glowBlur: 15,
  glowStrength: 0.8,
} as const;