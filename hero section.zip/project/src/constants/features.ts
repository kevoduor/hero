import { Activity, Calendar, FileText, Mic } from 'lucide-react';
import type { Feature } from '../types';

export const features: Feature[] = [
  {
    icon: Mic,
    title: 'Voice-Powered Search',
    description: 'Access patient information hands-free with natural voice commands'
  },
  {
    icon: Calendar,
    title: 'Smart Scheduling',
    description: 'AI-optimized appointment management and automated reminders'
  },
  {
    icon: FileText,
    title: 'Digital Records',
    description: 'Secure, centralized storage for patient histories and treatment plans'
  },
  {
    icon: Activity,
    title: 'Real-time Analytics',
    description: 'Comprehensive insights into clinic performance and patient care'
  }
];