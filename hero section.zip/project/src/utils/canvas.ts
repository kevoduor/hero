import { PARTICLE_CONFIG } from '../constants/theme';
import type { AudioParticle } from '../types';

export const createParticles = (count: number): AudioParticle[] => {
  const particles: AudioParticle[] = [];
  
  for (let i = 0; i < count; i++) {
    particles.push({
      x: 0,
      y: 0,
      radius: PARTICLE_CONFIG.minRadius + Math.random() * (PARTICLE_CONFIG.maxRadius - PARTICLE_CONFIG.minRadius),
      color: PARTICLE_CONFIG.colors[Math.floor(Math.random() * PARTICLE_CONFIG.colors.length)],
      velocity: PARTICLE_CONFIG.minVelocity + Math.random() * (PARTICLE_CONFIG.maxVelocity - PARTICLE_CONFIG.minVelocity),
      amplitude: PARTICLE_CONFIG.minAmplitude + Math.random() * (PARTICLE_CONFIG.maxAmplitude - PARTICLE_CONFIG.minAmplitude),
      angle: (Math.PI * 2 * i) / count
    });
  }
  
  return particles;
};